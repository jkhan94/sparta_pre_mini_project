# spart_miniProject

내일배움캠프 자바5기. <br>
사전캠프 미니프로젝트.
<br><br>

<ins>**작업파일**</ins> <br>
index.html : 한진경 <br>
jkhan.html: 한진경. index.html 헤더에서 제거.

작업할 파일의 이름은 이니셜입니다.<br>
MSJ.html : 팀원 문수정: 취미 등록 <br>
HSY.html : 팀원 홍서영: 팀원 소개, 공부 게시물, 댓글 게시판 <br>
CSH.html : 리더 최성훈: 프로젝트 개요 <br>
LMH.html : 팀원 이민호: mbti 입력 및 결과 출력 
